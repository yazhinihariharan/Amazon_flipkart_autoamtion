package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class amazon_flipkart_page {
	@FindBy(id="twotabsearchtextbox")
	public static WebElement  searchbox;
	@FindBy(xpath="//*[@id=\"nav-search\"]/form/div[2]/div/input")
	public static WebElement  search_icon;
	@FindBy(className="a-price-whole")
	public static WebElement  price_value;
	@FindBy(css=".LM6RPg")
	public static WebElement  search2;
	@FindBy(css=".vh79eN > svg:nth-child(1)")
	public static WebElement  searchicon2;
    @FindBy(css="div._1HmYoV:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > a:nth-child(1) > div:nth-child(2) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1)") 
	public static WebElement  price2;

	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
		
	

}

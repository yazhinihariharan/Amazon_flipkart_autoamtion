package tests;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;


import pages.amazon_flipkart_page;
import sun.awt.windows.ThemeReader;

public class amazon_test {

	@Test
	public void openamazon() throws InterruptedException, AWTException
	{
	 WebDriver driver;
	 System.setProperty("webdriver.chrome.driver",
			"C:\\Users\\Yazhini\\git\\blazedemo_autoamtion\\blaze_demo\\src\\main\\java\\Blaze_demo_documents\\chromedriver.exe");
	        
			driver = new ChromeDriver();
			driver.get("http://www.amazon.in");
			PageFactory.initElements(driver,amazon_flipkart_page.class); 
			amazon_flipkart_page.searchbox.sendKeys("iphone XR 64 GB- yellow");
			amazon_flipkart_page.search_icon.click();
			String amazon_price=amazon_flipkart_page.price_value.getText();
			System.out.println(amazon_price);
			driver.manage().window().maximize();
			driver.get("http://www.flipkart.com");
			Thread.sleep(3000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			Thread.sleep(3000);
			amazon_flipkart_page.search2.sendKeys("iphone XR 64 GB- yellow");
			amazon_flipkart_page.searchicon2.click();
			Thread.sleep(3000);
		    String flipkart_price=amazon_flipkart_page.price2.getText();
		    System.out.println(flipkart_price);
		    StringBuffer amazon_num=new StringBuffer();
		    for (int j=0; j<amazon_price.length(); j++) 
	        { 
	            if (Character.isDigit(amazon_price.charAt(j))) 
	            	amazon_num.append(amazon_price.charAt(j));
	        }
		    String k=amazon_num.toString();
		    int amazon_final=Integer.parseInt(k);
		    StringBuffer flipkart_num = new StringBuffer();
		    for (int i=0; i<flipkart_price.length(); i++) 
	        { 
	            if (Character.isDigit(flipkart_price.charAt(i))) 
	            	flipkart_num.append(flipkart_price.charAt(i));
	        }
			System.out.println(flipkart_num);
			String f=flipkart_num.toString();
			int Flikart_final=Integer.parseInt(f);
			
			if (amazon_final>Flikart_final)
		   {
			   System.out.println("Price in AMAZON IS HIGHEST");
		   }
		   else
		   {
			   System.out.println("price in flipkart is highest");
		   }
			
}
}
